package ru.pantone.mixer

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import kotlin.math.pow
import kotlin.math.sqrt

data class Lab(val l: Double, val a: Double, val b: Double)
data class BaseInk(val name: String, val lab: Lab)
data class PantoneColor(val name: String, val lab: Lab, val measured: Boolean = false, val note: String = "")
data class Calibration(val pantone: String, val reference: Lab, val measured: Lab, val date: String)

class Store(private val c: Context) {
    private val p=c.getSharedPreferences("kmp_v14",Context.MODE_PRIVATE)
    private fun loadLines(key:String)= (p.getString(key,"")?:"").lines().filter{it.isNotBlank()}
    fun inks()=loadLines("inks").mapNotNull{val x=it.split("|");runCatching{BaseInk(x[0],Lab(x[1].toDouble(),x[2].toDouble(),x[3].toDouble()))}.getOrNull()}.toMutableList()
    fun saveInks(x:List<BaseInk>){p.edit().putString("inks",x.joinToString("\n"){"${it.name}|${it.lab.l}|${it.lab.a}|${it.lab.b}"}).apply()}
    fun pantones()=loadLines("pantones").mapNotNull{val x=it.split("|");runCatching{PantoneColor(x[0],Lab(x[1].toDouble(),x[2].toDouble(),x[3].toDouble()),x.getOrNull(4)=="1",x.getOrNull(5)?:"")}.getOrNull()}.toMutableList()
    fun savePantones(x:List<PantoneColor>){p.edit().putString("pantones",x.joinToString("\n"){"${it.name}|${it.lab.l}|${it.lab.a}|${it.lab.b}|${if(it.measured)"1" else "0"}|${it.note}"}).apply()}
    fun bundledPantones(): List<PantoneColor> {
        return runCatching {
            c.assets.open("pantone_colors.csv").bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.mapNotNull { line ->
                    val x=line.split(";").map{it.trim()}
                    if(x.size<4) null else runCatching {
                        PantoneColor(x[0], Lab(x[1].toDouble(),x[2].toDouble(),x[3].toDouble()))
                    }.getOrNull()
                }.toList().distinctBy{it.name.lowercase(Locale.ROOT)}
            }
        }.getOrDefault(emptyList())
    }

    fun calibrations()=loadLines("cal").mapNotNull{val x=it.split("|");runCatching{Calibration(x[0],Lab(x[1].toDouble(),x[2].toDouble(),x[3].toDouble()),Lab(x[4].toDouble(),x[5].toDouble(),x[6].toDouble()),x.getOrNull(7)?:"")}.getOrNull()}
    fun saveCal(x:List<Calibration>){p.edit().putString("cal",x.joinToString("\n"){"${it.pantone}|${it.reference.l}|${it.reference.a}|${it.reference.b}|${it.measured.l}|${it.measured.a}|${it.measured.b}|${it.date}"}).apply()}
}

fun parseCsv(c:Context,uri:Uri):List<PantoneColor>{
    val out=mutableListOf<PantoneColor>()
    c.contentResolver.openInputStream(uri)?.use{ins->BufferedReader(InputStreamReader(ins,Charsets.UTF_8)).forEachLine{line->
        val s=line.trim(); if(s.isBlank()||s.startsWith("#"))return@forEachLine
        val sep=when{s.contains(";")->";";s.contains("\t")->"\t";s.contains("|")->"|";s.contains(",")->",";else->null}?:return@forEachLine
        val x=s.split(sep).map{it.trim()}; if(x.size<4)return@forEachLine
        runCatching{PantoneColor(x[0],Lab(x[1].replace(",",".").toDouble(),x[2].replace(",",".").toDouble(),x[3].replace(",",".").toDouble()))}.onSuccess{out.add(it)}
    }}
    return out.distinctBy{it.name.lowercase(Locale.ROOT)}
}

fun solve(t:Lab, inks:List<BaseInk>):List<Double>{
    if(inks.isEmpty())return emptyList(); val n=inks.size; var w=DoubleArray(n){1.0/n}
    fun e(x:DoubleArray):Double{val l=x.indices.sumOf{i->x[i]*inks[i].lab.l};val a=x.indices.sumOf{i->x[i]*inks[i].lab.a};val b=x.indices.sumOf{i->x[i]*inks[i].lab.b};return sqrt((l-t.l).pow(2)+(a-t.a).pow(2)+(b-t.b).pow(2))}
    var step=.15
    repeat(10000){var best=e(w);var ok=false;for(i in 0 until n)for(j in 0 until n)if(i!=j&&w[j]>1e-9){val m=minOf(step,w[j]);val z=w.copyOf();z[i]+=m;z[j]-=m;val q=e(z);if(q<best){w=z;best=q;ok=true}};if(!ok)step*=.995;if(step<1e-6)return@repeat}
    return w.toList()
}
fun mix(inks:List<BaseInk>,w:List<Double>)=Lab(inks.indices.sumOf{i->w[i]*inks[i].lab.l},inks.indices.sumOf{i->w[i]*inks[i].lab.a},inks.indices.sumOf{i->w[i]*inks[i].lab.b})
fun de(x:Lab,y:Lab)=sqrt((x.l-y.l).pow(2)+(x.a-y.a).pow(2)+(x.b-y.b).pow(2))

@Composable fun Footer(){Text("© 2026 Косимовский Сергей • Kosimovskiy Mixer Pantone • Все права защищены.",style=MaterialTheme.typography.labelSmall)}

@Composable fun App(){
    val c=androidx.compose.ui.platform.LocalContext.current; val st=remember{Store(c)}
    var inks by remember{mutableStateOf(st.inks().toList())}; var ps by remember{mutableStateOf(st.pantones().ifEmpty{st.bundledPantones()}.also{if(it.isNotEmpty()&&st.pantones().isEmpty())st.savePantones(it)}.toList())}
    var cals by remember{mutableStateOf(st.calibrations())}; var tab by remember{mutableIntStateOf(0)}
    var search by remember{mutableStateOf("")}; var sel by remember{mutableStateOf<PantoneColor?>(null)}; var grams by remember{mutableStateOf("100")}
    var recipe by remember{mutableStateOf<List<Double>>(emptyList())}; var msg by remember{mutableStateOf("")}
    var iname by remember{mutableStateOf("")};var il by remember{mutableStateOf("")};var ia by remember{mutableStateOf("")};var ib by remember{mutableStateOf("")}
    var ml by remember{mutableStateOf("")};var ma by remember{mutableStateOf("")};var mb by remember{mutableStateOf("")}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null){val x=parseCsv(c,u);if(x.isNotEmpty()){ps=x;st.savePantones(x);msg="Импортировано: ${x.size}"}}}

    MaterialTheme{Scaffold(topBar={CenterAlignedTopAppBar(title={Column(horizontalAlignment=Alignment.CenterHorizontally){Text("KOSIMOVSKIY MIXER");Text("PANTONE • v1.4",style=MaterialTheme.typography.labelSmall)}})},bottomBar={Footer()}){pad->
        Column(Modifier.padding(pad).fillMaxSize()){NavigationBar{
            NavigationBarItem(tab==0,{tab=0},icon={Icon(Icons.Default.Calculate,null)},label={Text("Замес")})
            NavigationBarItem(tab==1,{tab=1},icon={Icon(Icons.Default.Palette,null)},label={Text("Краски")})
            NavigationBarItem(tab==2,{tab=2},icon={Icon(Icons.Default.Storage,null)},label={Text("Pantone")})
            NavigationBarItem(tab==3,{tab=3},icon={Icon(Icons.Default.Tune,null)},label={Text("Обучение")})
            NavigationBarItem(tab==4,{tab=4},icon={Icon(Icons.Default.Info,null)},label={Text("Автор")})
        };Column(Modifier.padding(16.dp).fillMaxSize()){
        when(tab){
        0->{Text("РАСЧЁТ РЕЦЕПТА",style=MaterialTheme.typography.headlineSmall);OutlinedTextField(search,{search=it;sel=ps.firstOrNull{p->p.name.contains(search,true)}},label={Text("Pantone №")},modifier=Modifier.fillMaxWidth())
            if(search.isNotBlank())ps.filter{it.name.contains(search,true)}.take(10).forEach{TextButton({sel=it;search=it.name}){Text(it.name+(if(it.measured)"  • МОЙ ЭТАЛОН" else ""))}}
            sel?.let{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text("ЦЕЛЬ: ${it.name}",style=MaterialTheme.typography.titleMedium);Text("LAB ${"%.2f".format(Locale.US,it.lab.l)} / ${"%.2f".format(Locale.US,it.lab.a)} / ${"%.2f".format(Locale.US,it.lab.b)}")}}}
            Spacer(Modifier.height(8.dp));OutlinedTextField(grams,{grams=it},label={Text("Вес, г")},modifier=Modifier.fillMaxWidth());Button({if(sel==null)msg="Выберите Pantone" else if(inks.isEmpty())msg="Добавьте базовые краски" else{recipe=solve(sel!!.lab,inks);msg=""}},Modifier.fillMaxWidth()){Text("РАССЧИТАТЬ РАЗВЕСКУ")}
            if(msg.isNotBlank())Text(msg,color=MaterialTheme.colorScheme.error)
            if(recipe.isNotEmpty()&&sel!=null){val g=grams.toDoubleOrNull()?:100.0;val m=mix(inks,recipe);Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text("РАЗВЕСКА",style=MaterialTheme.typography.titleLarge);inks.forEachIndexed{i,k->if(recipe[i]>.0005)Text("${k.name}: ${"%.3f".format(Locale.US,recipe[i]*g)} г  (${ "%.2f".format(Locale.US,recipe[i]*100)}%)")};HorizontalDivider();Text("Прогноз LAB: ${"%.2f".format(Locale.US,m.l)} / ${"%.2f".format(Locale.US,m.a)} / ${"%.2f".format(Locale.US,m.b)}");Text("ΔE76: ${"%.2f".format(Locale.US,de(m,sel!!.lab))}")}}}}
        1->{Text("МОИ БАЗОВЫЕ КРАСКИ",style=MaterialTheme.typography.headlineSmall);OutlinedTextField(iname,{iname=it},label={Text("Название")},modifier=Modifier.fillMaxWidth());Row{OutlinedTextField(il,{il=it},label={Text("L*")},modifier=Modifier.weight(1f));OutlinedTextField(ia,{ia=it},label={Text("a*")},modifier=Modifier.weight(1f));OutlinedTextField(ib,{ib=it},label={Text("b*")},modifier=Modifier.weight(1f))};Button({val z=runCatching{BaseInk(iname.ifBlank{"Краска ${inks.size+1}"},Lab(il.toDouble(),ia.toDouble(),ib.toDouble()))}.getOrNull();if(z!=null){val x=inks.toMutableList();x.add(z);inks=x;st.saveInks(x);iname="";il="";ia="";ib=""}},Modifier.fillMaxWidth()){Text("ДОБАВИТЬ КРАСКУ")};LazyColumn{items(inks){Text("${it.name}: L ${it.lab.l} a ${it.lab.a} b ${it.lab.b}");HorizontalDivider()}}}
        2->{Text("БАЗА PANTONE",style=MaterialTheme.typography.headlineSmall);Text("Импорт CSV с LAB и редактирование любого цвета.");Button({picker.launch(arrayOf("text/*","text/csv"))},Modifier.fillMaxWidth()){Text("ИМПОРТИРОВАТЬ / ОБНОВИТЬ БАЗУ")};Text("Цветов в базе: ${ps.size}");LazyColumn{items(ps.take(200)){Text(it.name+(if(it.measured)"  • измерен тобой" else ""));HorizontalDivider()}}}
        3->{Text("ОБУЧЕНИЕ / КАЛИБРОВКА",style=MaterialTheme.typography.headlineSmall);Text("Измерь веер или свой образец спектрофотометром и внеси фактический LAB. Программа сохранит измерение и сможет заменить эталонный LAB этого Pantone.");Spacer(Modifier.height(8.dp));OutlinedTextField(search,{search=it;sel=ps.firstOrNull{p->p.name.equals(search,true)}},label={Text("Pantone №")},modifier=Modifier.fillMaxWidth());sel?.let{Text("Текущий LAB: ${it.lab.l}, ${it.lab.a}, ${it.lab.b}")};Row{OutlinedTextField(ml,{ml=it},label={Text("Измеренный L*")},modifier=Modifier.weight(1f));OutlinedTextField(ma,{ma=it},label={Text("a*")},modifier=Modifier.weight(1f));OutlinedTextField(mb,{mb=it},label={Text("b*")},modifier=Modifier.weight(1f))};Button({val q=runCatching{Lab(ml.toDouble(),ma.toDouble(),mb.toDouble())}.getOrNull();if(sel!=null&&q!=null){val old=sel!!;val x=ps.toMutableList();val i=x.indexOfFirst{it.name.equals(old.name,true)};if(i>=0){x[i]=old.copy(lab=q,measured=true,note="LAB измерен спектрофотометром");ps=x;st.savePantones(x);sel=x[i];val cc=cals.toMutableList();cc.add(Calibration(old.name,old.lab,q,"ручное измерение"));cals=cc;st.saveCal(cc);msg="Эталон ${old.name} обновлён вашим измерением"}}},Modifier.fillMaxWidth()){Text("СОХРАНИТЬ МОЙ LAB КАК ЭТАЛОН")};Spacer(Modifier.height(8.dp));Text("История измерений: ${cals.size}");LazyColumn{items(cals.takeLast(100).reversed()){Text("${it.pantone}: ${it.measured.l} / ${it.measured.a} / ${it.measured.b}");HorizontalDivider()}}}
        4->{Text("О ПРОГРАММЕ",style=MaterialTheme.typography.headlineSmall);Card{Column(Modifier.padding(18.dp)){Text("Kosimovskiy Mixer Pantone",style=MaterialTheme.typography.titleLarge);Text("Автор: Косимовский Сергей");Text("Версия: 1.4");Spacer(Modifier.height(8.dp));Text("© 2026 Косимовский Сергей. Все права защищены.");Text("Программа позволяет пользователю создавать собственную измеренную библиотеку эталонов.")}};Spacer(Modifier.height(10.dp));Text("Принцип обучения");Text("1) выбираешь Pantone; 2) измеряешь физический образец; 3) вводишь LAB; 4) сохраняешь измерение как свой рабочий эталон; 5) следующий рецепт использует твой LAB.");Text("Важно: для точности необходимо одинаковое измерительное условие, освещение/геометрия прибора и одинаковая подложка.")}}}}}}
    }}
}

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}
