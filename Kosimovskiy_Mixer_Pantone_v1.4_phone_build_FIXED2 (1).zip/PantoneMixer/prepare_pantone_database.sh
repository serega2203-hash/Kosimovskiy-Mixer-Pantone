#!/bin/sh
set -e
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
ASSETS="$ROOT/app/src/main/assets"
mkdir -p "$ASSETS"
curl -L "https://raw.githubusercontent.com/aj90909/unofficial-pantone-solid-coated-2024-v5/main/colors.csv" -o "$ASSETS/pantone_source.csv"
tail -n +2 "$ASSETS/pantone_source.csv" | awk -F',' '{print $1 ";" $3 ";" $4 ";" $5}' > "$ASSETS/pantone_colors.csv"
rm "$ASSETS/pantone_source.csv"
echo "Готово: 3219 Pantone LAB"
