plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
tasks.register("preparePantoneDatabase") {
    val out = layout.projectDirectory.dir("src/main/assets")
    doLast {
        val dir = out.asFile
        dir.mkdirs()
        val target = dir.resolve("pantone_colors.csv")
        val url = java.net.URI("https://raw.githubusercontent.com/aj90909/unofficial-pantone-solid-coated-2024-v5/main/colors.csv").toURL()
        url.openStream().use { input -> target.outputStream().use { output -> input.copyTo(output) } }
        println("Pantone database saved to $target")
    }
}

tasks.matching { it.name in listOf("preDebugBuild", "preReleaseBuild") }.configureEach { dependsOn("preparePantoneDatabase") }

android {
    namespace = "ru.pantone.mixer"
    compileSdk = 36
    defaultConfig {
        applicationId = "ru.kosimovskiy.mixer.pantone"
        minSdk = 26
        targetSdk = 36
        versionCode = 14
        versionName = "1.4"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.activity:activity-compose:1.13.0")
    implementation(platform("androidx.compose:compose-bom:2026.08.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
}
