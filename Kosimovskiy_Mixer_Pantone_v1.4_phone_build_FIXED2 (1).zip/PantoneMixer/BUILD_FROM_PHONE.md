# Сборка APK прямо с телефона

1. Создай аккаунт на GitHub и новый репозиторий, например `Kosimovskiy-Mixer-Pantone`.
2. Открой репозиторий в браузере телефона.
3. Выбери **Add file → Upload files**.
4. Загрузи содержимое папки `PantoneMixer` из этого архива (не сам ZIP): все папки и файлы, включая `.github/workflows/build-apk.yml`.
5. Нажми **Commit changes**.
6. Открой вкладку **Actions** → workflow **Build Kosimovskiy Mixer Pantone APK**.
7. Дождись зелёной галочки.
8. Открой завершённый запуск. Внизу **Artifacts** скачай `Kosimovskiy-Mixer-Pantone-v1.4-APK`.
9. Распакуй скачанный ZIP — внутри будет APK. Нажми APK на телефоне и установи.

После этого при каждом новом изменении можно запускать workflow вручную через **Run workflow**.
