$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$assets = Join-Path $root "app\src\main\assets"
New-Item -ItemType Directory -Force -Path $assets | Out-Null
$url = "https://raw.githubusercontent.com/aj90909/unofficial-pantone-solid-coated-2024-v5/main/colors.csv"
$csv = Join-Path $assets "pantone_source.csv"
Invoke-WebRequest -Uri $url -OutFile $csv
$out = Join-Path $assets "pantone_colors.csv"
$lines = Get-Content $csv | Select-Object -Skip 1
$sb = New-Object System.Text.StringBuilder
foreach ($line in $lines) {
  $p = $line -split ","
  if ($p.Count -ge 5) {
    [void]$sb.AppendLine(("{0};{1};{2};{3}" -f $p[0],$p[2],$p[3],$p[4]))
  }
}
[IO.File]::WriteAllText($out,$sb.ToString(),(New-Object System.Text.UTF8Encoding($false)))
Remove-Item $csv -Force
Write-Host "Готово. База Pantone: $out"
